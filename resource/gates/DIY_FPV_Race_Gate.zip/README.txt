                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2236847
DIY FPV Race Gate by Modz_FPV is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

DIY FPV Race Gate V1

An easy to make, lightweight DIY gate for drone racing.

I have included all the connections I have designed for my DIY FPV racing gates that are very lightweight, strong and easy on your quad when you hit them.

The gates are made from 22mm diameter PVC pipe and pipe lagging or swimming pool noodles.

I have also included a 22mm joiner so you can half the main 57" section into 2 and join them together if you need to travel a little more compact.

If you have any questions feel free to ask.

# Materials Needed (per gate)

TUBING
4x : 22mm PVC tube 15"
2x : 22mm PVC tube 24"
1x : 22mm PVC tube 57"

CONNECTORS
2x : 22mm PVC pipe 4 way connector (Included here)
4x : 22mm PVC pipe end cap (included here)

FOAM
3x : Swimming pool noodles or foam pipe lagging